# Tổng hợp thay đổi và phương án đề xuất: PBL6, dự báo mưa Đà Nẵng mới

> **Mục đích:** tài liệu đầu vào để gộp với phương án của nhóm khác hoặc của AI khác, nhằm ra phương án cuối cùng. Tài liệu tự đứng được: không cần đọc lịch sử trao đổi trước đó.
> **Cập nhật:** 20/10/2026. **Repo:** https://github.com/nibsu05/PBL6, nhánh `main`, commit `e531982`.
> **Tài liệu chi tiết hơn trong repo:** `project_plan_v2.md` (kỹ thuật và số liệu), `KE_HOACH_DU_AN.md` (kế hoạch cho nhóm), `CLAUDE.md` (bối cảnh cho agent), `reports/station_benchmark/README.md` (bảng đối chiếu với trạm).

## 0. Cách đọc tài liệu này (dành cho người hoặc AI sẽ gộp phương án)

Mỗi nội dung được gắn một trong bốn nhãn:

| Nhãn | Ý nghĩa | Khi gộp với phương án khác |
| --- | --- | --- |
| **[CHỐT · BẰNG CHỨNG]** | Quyết định dựa trên số liệu đo trên dữ liệu thật | Chỉ thay đổi khi có bằng chứng mới mạnh hơn, đo cùng cách |
| **[CHỐT · NHÓM]** | Nhóm hoặc giảng viên đã đồng ý | Giữ, trừ khi nhóm chủ động đổi |
| **[ĐỀ XUẤT]** | Phương án khuyên dùng, còn bàn được | Có thể thay nếu phương án khác hợp lý hơn |
| **[ĐÃ LÀM]** | Đã có code, dữ liệu hoặc kết quả trong repo | Tái sử dụng được ngay |

Số liệu trong tài liệu đều tính lại được bằng các script có sẵn trong repo (mục 9).

---

## 1. Bối cảnh

- **Đề tài:** dự báo lượng mưa ngắn hạn và dài hạn cho một số tỉnh/thành Việt Nam, bắt đầu với Đà Nẵng. Dự định ban đầu:
  - Ngắn hạn dùng Bi-LSTM, dài hạn dùng Informer.
  - So sánh cùng một mô hình khi thêm các nhóm đặc trưng nâng cao khác nhau.
  - Cuối cùng làm một app.
- **Dữ liệu ban đầu:** chuỗi theo giờ tại **một tọa độ** ở Đà Nẵng (16,0544°B, 108,2022°Đ), giai đoạn 2015–2026, gồm:
  - Biến bề mặt Open-Meteo: nhiệt độ, độ ẩm, áp suất, gió, mưa.
  - ERA5: gió và ẩm tầng 850 hPa, SST, CAPE/CIN/TCWV/độ ẩm đất (từ một hộp nhỏ).
  - Chỉ số ONI.
  - **Nhãn:** mưa Open-Meteo Archive, về bản chất là mưa tái phân tích ERA5.
- **Máy:** MacBook M2 8 GB RAM (dữ liệu, code, chạy thử) và một máy có RTX 4060 8 GB (huấn luyện dài).
- **Hạn nộp giả định:** cuối tháng 12/2026 (chưa xác nhận).

---

## 2. Bảng tóm tắt mọi quyết định

| # | Quyết định | Nhãn | Căn cứ chính (chi tiết ở mục ghi trong ngoặc) |
| --- | --- | --- | --- |
| D1 | **Không dùng ERA5 (mưa Open-Meteo) làm nhãn** | CHỐT · BẰNG CHỨNG | Chỉ bắt được 8 % số ngày ≥100 mm tại trạm Đà Nẵng; nhãn và đầu vào cùng nguồn (mục 3.1) |
| D2 | **Nhãn mới: GSMaP v8 hiệu chỉnh trạm**; IMERG Final là nhãn kiểm tra độ bền | CHỐT · BẰNG CHỨNG + NHÓM (Cổng 1, 11/10/2026) | CSI ≥50 mm là 0,33, so với IMERG 0,22 và ERA5 0,17, trên 10 trạm (mục 3.2) |
| D3 | Đơn vị dự báo là **ô lưới 0,1°** (khoảng 11 km); một tỉnh là tập các ô trong ranh giới 34 tỉnh mới | CHỐT · NHÓM | Đà Nẵng mới gồm cả Quảng Nam, khoảng 11.860 km², từ biển lên núi (mục 4.2) |
| D4 | **Một mô hình chung cho mọi ô**, kèm đặc trưng tĩnh; không huấn luyện riêng từng tỉnh | ĐỀ XUẤT (khuyên mạnh) | Kratzert 2019, Montero-Manso & Hyndman 2021, Rasp & Lerch 2018; gộp ô làm tăng số sự kiện (mục 4.3) |
| D5 | Vùng trọng tâm là **Đà Nẵng mới**; thêm 2 vùng kiểm tra tổng quát hóa | ĐỀ XUẤT | Vùng phía nam còn chờ chọn (mục 12) |
| D6 | **Sản phẩm A** (0–6 giờ): **giữ Bi-LSTM**, thiết kế lại đầu vào | CHỐT · NHÓM | Kiến trúc không phải đòn bẩy chính; đầu vào và nhãn mới quyết định (mục 5.1) |
| D7 | **Sản phẩm B** (1–3 ngày): **TFT thay Informer**; Informer chạy một cấu hình để đối chiếu | CHỐT · NHÓM (giảng viên không bắt buộc Informer) | Informer kém cả phương án ngây thơ trên bộ chuẩn; thiếu cơ chế cho đầu vào tương lai và đặc trưng tĩnh (mục 5.2) |
| D8 | Vai trò AI là **hậu xử lý dự báo số cộng nowcasting**; đối thủ chính là **ECMWF thô** | ĐỀ XUẤT (khuyên mạnh) | Ở hạn 1–3 ngày, lịch sử mưa gần như không mang thông tin; ECMWF là nguồn kỹ năng chính (mục 7) |
| D9 | **Chỉ số chính:** CSI theo ngưỡng mưa vừa/to/rất to, BSS, reliability; **không dùng MAE** | CHỐT · BẰNG CHỨNG | "Luôn dự báo 0" có MAE rất thấp; mọi dự báo tất định đều có BSS < 0 (mục 6.5, 7) |
| D10 | Sản phẩm A **chỉ chấm theo giờ trong tháng 5–10**; mùa đông chỉ chấm tổng 6 giờ và 24 giờ; mọi bảng tách theo mùa | CHỐT · BẰNG CHỨNG | Vệ tinh gần như không thấy mưa mùa đông; nhãn giờ khi đó được trải đều (mục 3.4) |
| D11 | Ablation theo nhóm đặc trưng, cố định kiến trúc, 3 seed, bootstrap theo cặp, chia theo năm, test chỉ mở một lần | ĐỀ XUẤT (chuẩn phương pháp) | Một năm tại một điểm cho khoảng tin cậy CSI rộng 0,35 (mục 6) |
| D12 | Đánh giá cả **T-ERA5** (perfect prog) và **T-OPS** (dự báo thật lưu trữ) | ĐỀ XUẤT | Đo được hiệu năng khi chạy app thật (mục 6.6) |
| D13 | Đầu vào quan trắc là **GSMaP thô dịch trễ L giờ**; có thí nghiệm độ trễ | ĐỀ XUẤT | GSMaP gần thời gian thực trễ khoảng 4 giờ, nên triển khai được (mục 6.3) |
| D14 | Kiểm chứng độc lập chỉ dựa vào **10 trạm NOAA GSOD** (đến 24/08/2025); **không có Vrain** | CHỐT (ràng buộc thực tế) | Nhóm không xin được dữ liệu Vrain (mục 3.3) |
| D15 | Thuật ngữ theo Thông tư 08/2022: **cực ngắn ≤12 giờ, ngắn 12–72 giờ, vừa 3–10 ngày**; không gọi 24–72 giờ là "dài hạn" | CHỐT · BẰNG CHỨNG (quy định) | Thông tư 08/2022/TT-BTNMT |

---

## 3. Dữ liệu

### 3.1. Dữ liệu cũ có vấn đề gì [CHỐT · BẰNG CHỨNG]

| # | Vấn đề | Bằng chứng (tính lại từ dữ liệu thật) |
| --- | --- | --- |
| 1 | **Nhãn sai cường độ mưa to.** Nhãn là mưa do mô hình tính ra, không phải mưa đo được. | So với trạm sân bay Đà Nẵng (NOAA GSOD 48855), 2015–2024, 3.453 ngày có đủ mọi nguồn: trạm có **51 ngày ≥100 mm**, nhãn cũ có **11 ngày** và chỉ **trùng 4 ngày** (POD 0,08, CSI 0,07). Với ngày ≥50 mm: trạm 131 ngày, nhãn 70, trùng 37. Tương quan theo ngày 0,56. Trận 14/10/2022: trạm 396 mm, nhãn 186 mm. 15/10/2022: 280 so với 20 mm. 13/10/2023: 409 so với 84 mm. 14/10/2023: 372 so với 135 mm. |
| 2 | **Nhãn và đầu vào cùng nguồn (ERA5).** | Cùng bộ đặc trưng ERA5 theo ngày, dùng gradient boosting, train 2015–2020, test 2021–2024: R² (log1p) = **0,70** khi đoán mưa ERA5, chỉ **0,42** khi đoán mưa trạm; CSI ≥16 mm là 0,49 so với 0,30. Ablation dùng nhãn ERA5 sẽ thổi phồng giá trị của đặc trưng. |
| 3 | **Không chạy được ngoài thực tế.** | Đầu vào có mưa giờ trước lấy từ chính nhãn; ERA5 trễ khoảng 5 ngày; không có trạm nào công khai số liệu theo giờ. |
| 4 | **Một điểm cho cả tỉnh, và quá ít sự kiện.** | Sau 01/07/2025, Đà Nẵng mới gồm cả Quảng Nam (Nghị quyết 202/2025/QH15). Tại một trạm, độ rộng khoảng tin cậy 95 % của CSI ≥50 mm: **0,35** nếu test 1 năm (19 ngày mưa to); 0,20 nếu 4 năm; 0,13 nếu 10 năm. Trong khi đó, một nhóm đặc trưng thường chỉ đổi CSI khoảng 0,02–0,05. |
| 5 | **Lỗi xử lý dữ liệu.** | CIN bị thiếu (không có mực đối lưu tự do) được điền 0, tức "không có lực cản", ngược ý nghĩa; **41,4 % số giờ** bị ảnh hưởng. `is_convective` luôn bằng 1. `bfill` lấy giá trị tương lai. Hướng gió lưu dạng độ. Chia 70/15/15 theo số dòng nên test chỉ có một mùa mưa. |

**Kết quả mô hình cũ cần đọc lại:**
- Bi-LSTM (24 → 6 giờ) có MAE 0,326, kém phương án "luôn dự báo 0" (0,265); ở +1 giờ thua persistence.
- Informer (168 → 24 giờ): R² = 0,039; MAE 0,309, trong khi "luôn dự báo 0" là 0,230.
- Câu "Informer vượt Bi-LSTM 21 %" trong báo cáo cũ so hai mô hình trên **tập test khác nhau**.

### 3.2. Thí nghiệm 0: chọn nhãn mới [CHỐT · BẰNG CHỨNG] [ĐÃ LÀM]

- **Cách làm:** chấm 4 ứng viên theo cùng một giao thức (`src/verification.py`) trên **10 trạm synop NOAA** đã qua kiểm soát chất lượng, giai đoạn 2021–2024: 13.836 trạm-ngày, **437 ngày ≥50 mm**, 138 ngày ≥100 mm. Mọi nguồn được chấm trên cùng tập (trạm, ngày); ngày tính theo UTC.

| Nguồn | CC | CSI ≥16 mm | CSI ≥50 mm | FBI ≥50 mm | CSI ≥100 mm | BSS ≥50 mm |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| ERA5 (nhãn cũ) | 0,55 | 0,28 | 0,17 | 0,44 | 0,11 | −0,11 |
| IMERG Final V07 | 0,56 | 0,29 | 0,22 | 0,78 | 0,20 | −0,25 |
| GSMaP v8 thô | 0,50 | 0,25 | 0,19 | 0,82 | 0,18 | −0,35 |
| **GSMaP v8 hiệu chỉnh trạm** | **0,72** | **0,42** | **0,33** | 0,78 | **0,29** | **+0,02** |

- **Hiệu số so với ERA5** (bootstrap theo cặp, khối 5 ngày, 1.000 lần): CSI ≥50 mm tăng **+0,16**, khoảng tin cậy 95 % **[0,11; 0,21]**. IMERG tăng +0,05 [0,01; 0,09].
- **Tại riêng trạm Đà Nẵng, ngày ≥100 mm:** GSMaP hiệu chỉnh trùng **29/51** ngày của trạm, IMERG 18/51, ERA5 4/51.
- **Theo mùa, vùng Trung Trung Bộ, CSI ≥50 mm của GSMaP hiệu chỉnh:** 0,46 vào mùa hè–thu (tháng 5–10), 0,43 vào mùa đông.
- **Giới hạn cần ghi:**
  - GSMaP được hiệu chỉnh theo phân tích mưa ngày của NOAA CPC, có thể gồm chính các trạm kiểm chứng, nên điểm tại trạm cao hơn thực tế.
  - Ở những nơi có thể thiếu trạm trong phân tích CPC, như Hà Đông và Nhà Bè, GSMaP hiệu chỉnh không hơn ERA5.
  - Nhãn mới cũng không đúng từng ngày: 14/10/2022 cho 474 mm, cao hơn trạm 396 mm; 14/10/2023 chỉ 129 mm so với 372 mm của trạm.
- **Lý do thực tế để chọn GSMaP thay vì IMERG:**
  - Trên Google Earth Engine, IMERG V07 bản permanent chỉ có đến 30/09/2025.
  - GSMaP có liên tục đến hiện tại.
  - Bản GSMaP thô cùng họ với GSMaP NRT/NOW, tức nguồn dùng được khi app chạy thật.

### 3.3. Dữ liệu mới (dataset v2) [ĐÃ LÀM]

| Thành phần | Nguồn | Chi tiết |
| --- | --- | --- |
| **Nhãn** | GSMaP v8 `hourlyPrecipRateGC` (GEE `JAXA/GPM_L3/GSMaP/v8/operational`) | Theo giờ, 0,1°; chỉ dùng ảnh bản *permanent* |
| **Quan trắc đầu vào** (nhóm A1) | GSMaP v8 `hourlyPrecipRate` (bản thô) | Dataloader dịch trễ L giờ |
| **Khí quyển** | ERA5 trên GEE (`ECMWF/ERA5/HOURLY`), **33 biến** trên 169 nút 0,25° (hộp 14–17°B × 106,5–109,5°Đ) cùng 4 điểm synop | Bề mặt (nhiệt độ, điểm sương, áp suất bề mặt, MSLP, gió 10 m, mây tổng/thấp/trung/cao); CAPE, CIN, TCWV, K-index, Total Totals, BLH; thông lượng ẩm tích phân u/v và phân kỳ; mưa ERA5; u/v/q/T/omega ở 850 và 500 hPa, RH 850; SST; độ ẩm đất. **GEE chỉ có tầng 850 và 500 hPa.** Nội suy song tuyến về tâm ô 0,1°. |
| **Đặc trưng tĩnh** | Copernicus DEM GLO30_2024_1; ranh giới FAO GAUL 2015, ánh xạ sang 34 tỉnh mới | Độ cao trung bình/độ lệch/cực đại, tỷ lệ biển, khoảng cách tới biển, chênh độ cao hướng đông bắc (sườn đón gió), tỉnh mới |
| **Kiểm chứng** | NOAA GSOD: 12 trạm ứng viên, **10 trạm dùng được** (Nội Bài và Cần Thơ báo toàn 0 nên bị loại) | Mưa ngày, chỉ giữ cờ D/F/G (đủ 24 giờ) và I (ngày khô); **dữ liệu dừng ở 24/08/2025** |
| **Dự báo số lưu trữ** (mức sàn, T-OPS) | Open-Meteo Previous Runs (ECMWF IFS 0,25°, GFS, dự báo trước 1/2/3/5 ngày, từ 02/2024) | Previous Runs **không có CAPE/TCWV**. Single Runs (ECMWF IFS 9 km, từ 14/03/2024) có mưa, CAPE, TCWV, nhưng biến 850 hPa trả rỗng. Historical Forecast có IFS 9 km từ 2017. |

- **Lưới:** 380 ô 0,1° trong hộp 14,6–16,5°B × 107–109°Đ. Trong đó **296 ô đất**, và **214 ô thuộc Việt Nam**: 93 Đà Nẵng mới (ô thứ 94 phần lớn là biển), 85 Quảng Ngãi, 32 Huế, 4 ô giáp ranh. Các ô còn lại thuộc Lào.
- **Thời gian:** 01/2015 → 09/2026, theo giờ; khối dữ liệu 296 ô × 105.192 giờ × 51 đặc trưng; thiếu dữ liệu dưới 0,2 % mỗi năm.
- **Quy ước:**
  - Hàng `t` là khoảng `[t, t+1h)` UTC.
  - Mưa ERA5/Open-Meteo ghi ở *cuối* giờ, nên dịch lùi 1 giờ. GSMaP và IMERG ghi ở *đầu* khoảng.
  - **CIN bị mask được mã hóa thành `cin_capped = 500` và `has_lfc = 0`**; giờ thiếu hẳn ERA5 thì để NaN.
- **Kích thước:** dữ liệu nguồn **2,9 GB** (gói `pbl6_data_v2_2026-10-11.tar`, 2.233 file, có checksum trong `data/DATA_MANIFEST_v2.json`). Dataset dựng ra khoảng 12 GB, dựng lại trong khoảng 3 phút.

### 3.4. Phát hiện khi làm dữ liệu mới [CHỐT · BẰNG CHỨNG]

1. **Vệ tinh gần như không thấy mưa mùa đông (tháng 11–2) ở Trung Bộ**, vì đây là mưa từ mây thấp, mưa địa hình. Tại trạm Trung Trung Bộ, 2021–2024, mùa đông:
   - GSMaP thô: bias −7,8 mm/ngày, FBI ≥16 mm 0,17.
   - IMERG: bias −5,0 mm/ngày, FBI 0,41.
   - Hệ quả: vào mùa đông, nhãn theo giờ là **tổng mưa ngày trải đều ra các giờ**. Ví dụ 16/12/2015, nhãn khoảng 2,6–2,8 mm/giờ liên tục 18 giờ trong khi GSMaP thô gần bằng 0. Có 56 % lượng mưa mùa đông của nhãn rơi vào giờ mà vệ tinh thấy 0; mùa hè–thu là 25 %.
   - Từ đây ra quyết định D10.
2. **ERA5 có "mưa phùn giả" vào mùa khô:** từ tháng 1 đến 8, ERA5 cho lượng mưa gấp 2–10 lần nhãn ở vùng núi. Đây là sai số AI có cơ hội sửa.
3. **Năm 2015 lệch thấp ở vùng núi:** nhãn vùng núi chỉ 1.109 mm, thấp hơn cả GSMaP thô (1.492 mm); tại điểm trạm vẫn khớp, lệch 12 %. Năm 2015 chỉ nằm trong tập train; có thể thử bỏ năm này để kiểm tra độ bền.
4. **Lỗi dữ liệu phía nguồn:** GFS "trước 5 ngày" trên Open-Meteo thấp khoảng 50 % ở mọi quý, nên đã loại.
5. **Lỗi kỹ thuật đã sửa:**
   - ERA5 trên GEE phải lấy theo `crsTransform=[0.25,0,-180.125,0,-0.25,90.125]`; dùng `scale` sẽ lệch nửa ô.
   - pandas 3 lưu thời gian theo micro giây, nên phải ép kiểu `datetime64[ns]`.
   - Ngày 31/12 bị mất khi cộng mưa theo từng năm riêng lẻ.
   - ARCO-ERA5 có đủ biến, nhưng mỗi chunk là 1 giờ × toàn cầu, nên không hợp để rút chuỗi dài cho một vùng.

---

## 4. Bài toán và phạm vi

### 4.1. Hai sản phẩm [CHỐT · NHÓM]

| | Sản phẩm A: cực ngắn | Sản phẩm B: hạn ngắn |
| --- | --- | --- |
| Mô hình | Bi-LSTM | TFT |
| Hạn | t+1 … t+6 giờ, từng giờ | t+1 … t+72 giờ (có thể mở rộng đến 7 ngày) |
| Phát hành | Mỗi giờ | 00/06/12/18 UTC |
| Hiển thị | Tổng mưa 3 giờ tới; xác suất có mưa và mưa to | Tổng mưa ngày 1–3, chia khối 6 giờ; xác suất ≥16/50/100 mm/24 giờ (mưa vừa / to / rất to) |
| Cửa sổ đầu vào | 24 giờ | 168 giờ |

Không làm dự báo "dài hạn" thật (10 ngày – 1 tháng): 11 năm dữ liệu chỉ tương ứng khoảng 11 mùa mưa, quá ít mẫu độc lập.

### 4.2. Đơn vị không gian [CHỐT · NHÓM]

- Ô 0,1° trùng lưới GSMaP. Một tỉnh là tập các ô có tâm nằm trong ranh giới 34 tỉnh mới. Một xã được gán vào ô chứa tâm của xã.
- App hiển thị cấp tỉnh (trung bình, nơi mưa nhiều nhất, % diện tích mưa to) và cấp điểm. Luôn ghi chú: "lượng mưa trung bình ô khoảng 11 km, không phải số đo tại điểm".

### 4.3. Một mô hình chung, không làm riêng từng tỉnh [ĐỀ XUẤT, khuyên mạnh]

| Phương án | Ưu | Nhược | Đề xuất |
| --- | --- | --- | --- |
| Mỗi tỉnh một mô hình | Đơn giản | 34 mô hình; tỉnh ít mưa to thiếu mẫu; không dự báo được nơi chưa huấn luyện | Chỉ làm đối chứng trong thí nghiệm "chung so với riêng" |
| **Một mô hình chung**, kèm đặc trưng tĩnh | Học từ mọi vùng; nhiều mẫu mưa to; chạy được cho ô mới; triển khai một mô hình | Cần kiểm tra khả năng tổng quát hóa | **Chọn** |
| Mô hình lưới (ConvLSTM, U-Net) | Dùng trọn cấu trúc không gian | Lệch đề tài; nặng | Hướng mở rộng |

**Căn cứ:**
- Kratzert et al. (2019, HESS): một LSTM huấn luyện chung trên 531 lưu vực thắng mô hình hiệu chỉnh riêng từng lưu vực.
- Kratzert et al. (2019, WRR): ở lưu vực không có trong tập huấn luyện, LSTM vẫn đạt NSE 0,69, so với SAC-SMA 0,64 và NWM 0,58.
- Montero-Manso & Hyndman (2021): chứng minh mô hình chung không kém mô hình riêng về khả năng biểu diễn.
- Rasp & Lerch (2018): một mạng chung cho mọi trạm, mỗi trạm có một embedding.

**Phạm vi:**
- **Trọng tâm:** Đà Nẵng mới (cùng phần Huế và Quảng Ngãi đã có trong hộp dữ liệu), chạy toàn bộ thí nghiệm.
- **Kiểm tra tổng quát hóa:** Hà Nội, cùng TP.HCM **hoặc** Đắk Lắk (chờ chọn). Chỉ chạy cấu hình cuối, baseline, so sánh chung với riêng, và bỏ một vùng.
- Tải thêm vùng bằng cùng các script, chỉ đổi `--bbox`; mỗi vùng khoảng 1–2 giờ.

---

## 5. Mô hình

### 5.1. Sản phẩm A: Bi-LSTM [CHỐT · NHÓM]

- **Giữ Bi-LSTM**, vì bằng chứng so sánh giữa Bi-LSTM, LSTM và GRU cho kết quả lẫn lộn, chênh lệch nhỏ. Thứ quyết định chất lượng là đầu vào và nhãn.
- **Đầu ra hai đầu** (tái dùng ý tưởng `RainAlertBiLSTM` cũ): lượng mưa (log1p, Huber) và xác suất vượt ngưỡng (BCE).
- Dự báo số ở các giờ tới (nhóm A4) đưa vào qua một nhánh riêng, hoặc nối thêm các bước tương lai kèm cờ đánh dấu.

### 5.2. Sản phẩm B: TFT thay Informer [CHỐT · NHÓM]

**Lý do không chọn Informer:**
1. **Thiết kế lệch bài toán:** ProbSparse sinh ra để tiết kiệm tính toán cho chuỗi rất dài; ở đây chỉ 168 → 72 bước.
2. **Kết quả trên bộ chuẩn Weather** (MSE, Zeng et al., AAAI 2023): Informer kém cả phương án lặp lại giá trị gần nhất.

   | Hạn (bước) | Informer | Lặp lại | DLinear |
   | ---: | ---: | ---: | ---: |
   | 96 | 0,300 | 0,259 | 0,176 |
   | 192 | 0,598 | 0,309 | 0,220 |
   | 336 | 0,578 | 0,377 | 0,265 |
   | 720 | 1,059 | 0,465 | 0,323 |

3. **Kết quả của nhóm:** R² = 0,04.
4. **Thiếu cơ chế** cho dự báo số ở giờ tương lai và cho đặc trưng tĩnh, trong khi đây là hai loại đầu vào quan trọng nhất ở hạn 1–3 ngày (tự tương quan của mưa theo ngày chỉ còn 0,14 ở độ trễ 3 ngày).

**Lý do chọn TFT** (Lim et al., 2021):
- Có cơ chế riêng cho ba loại đầu vào: đặc trưng tĩnh, đầu vào biết trước cho tương lai, chuỗi quan sát quá khứ.
- Xuất được phân vị (tức xác suất), và có trọng số chọn biến (để giải thích, bổ sung cho ablation).
- Bằng chứng trong thủy văn: Koya & Roy (2023), trên 2.610 lưu vực Caravan, TFT vượt LSTM và Transformer. Một nghiên cứu trên 671 lưu vực CAMELS cho KGE 0,87, so với 0,81 của LSTM có đặc trưng tĩnh. Có nghiên cứu khác cho kết quả lẫn lộn, nên vẫn phải so với baseline.

**Triển khai [ĐỀ XUẤT]:**
- **Tự cài đặt TFT gọn bằng PyTorch** (khoảng 300–400 dòng), gồm GRN, khối chọn biến past/future/static, encoder–decoder LSTM, attention có thể diễn giải. Mô hình đọc thẳng từ `WindowSampler`.
- **Không dùng `pytorch-forecasting`**, vì thư viện này dựng dữ liệu bằng DataFrame, không vừa 8 GB RAM với 2,2 triệu cửa sổ.
- **Khởi đầu:** hidden 64, 4 đầu attention, dropout 0,1; mỗi epoch rút khoảng 300.000 cửa sổ.
- **Hàm mất mát:** phân vị 0,1/0,5/0,9 trên log1p mưa giờ, cộng số hạng trên tổng 24 giờ, cộng BCE cho xác suất ngày vượt 16/50/100 mm.
- **Informer** chạy một cấu hình (B0–B3, dự báo số đưa vào decoder; code cũ ở `src/informer/`) để giải thích vì sao đổi mô hình.
- **Tùy chọn:** TiDE (Das et al., 2023) làm đối chứng thêm.

### 5.3. Thang baseline [ĐỀ XUẤT, bắt buộc phải có]

| Baseline | A (0–6 giờ) | B (1–3 ngày) |
| --- | :---: | :---: |
| Khí hậu (ô × tháng × giờ, hoặc theo ngày trong năm) | ✓ | ✓ |
| Persistence có độ trễ thật (GSMaP thô lúc t − L) | ✓ | — |
| ECMWF thô (và mưa ERA5 thô) | ✓ | ✓ |
| ECMWF + quantile mapping | ✓ | ✓ |
| LightGBM với cùng đặc trưng | ✓ | ✓ |
| DLinear | — | ✓ |
| Informer (một cấu hình) | — | ✓ |
| Oracle (quan trắc với L = 0, không triển khai được) | ✓ | — |

Thêm **bảng 2×2**: Bi-LSTM và TFT, mỗi mô hình chạy cả hai hạn, để bảo vệ lựa chọn kiến trúc. Có tiền lệ trong nước: hậu xử lý ECMWF cho Trung Bộ bằng quantile mapping (Trần An Đức và cộng sự, 2025, 41 trạm, 2013–2022) cải thiện ở mọi hạn, nhưng **gần như không giúp với mưa lớn**. Đó là khoảng trống AI nhắm vào.

---

## 6. Thiết kế thí nghiệm

### 6.1. Nhóm đặc trưng [ĐỀ XUẤT] [ĐÃ LÀM trong `src/dataloader_v2.py`, `FEATURE_GROUPS`]

"past" là chuỗi quá khứ; "obs" là quan trắc dịch trễ L giờ; "future" là giá trị tại giờ đích (ERA5 khi train, ECMWF khi chạy thật). Mọi cấu hình đều có thêm sin/cos của giờ và ngày trong năm, cùng 8 đặc trưng tĩnh.

| Nhóm | Nội dung |
| --- | --- |
| **A0** Nền | past: t2m, td2m, rh2m, sp, mslp, u10, v10, tcc, lcc, mcc, hcc |
| **A1** Quan trắc gần | obs: GSMaP thô tại ô, trung bình 5×5 ô, cực đại 5×5 ô |
| **A2** Đối lưu | past: CAPE, cin_capped, has_lfc, TCWV, K-index, Total Totals, BLH |
| **A3** Tầng cao và dòng ẩm | past: IVT u/v/độ lớn, phân kỳ ẩm, u/v/q/T/omega/RH 850 hPa, u/v/q/T/omega 500 hPa, đứt gió 850–500 hPa |
| **A4** Dự báo số | past: mưa ERA5. future: mưa ERA5, CAPE, TCWV, IVT, u850, v850 |
| **A5** Bối cảnh vùng | past: TCWV và IVT trung bình 3×3 nút ERA5 |
| **B0** Nền | past: như A0. obs: GSMaP thô |
| **B1** Hình thế synop | past: chỉ số không khí lạnh (MSLP Hà Nội − Đà Nẵng), chênh MSLP vịnh Bắc Bộ − Nam Trung Bộ, u850, v850, TCWV, IVT |
| **B2** Đối lưu | past: CAPE, cin_capped, has_lfc, K-index, Total Totals |
| **B3** Dự báo số tương lai (vào decoder) | future: mưa ERA5, TCWV, CAPE, MSLP, u850, v850, IVT, chỉ số không khí lạnh |
| **B4** Khí hậu quy mô lớn | past: SST vùng biển (sẽ thêm MJO, Niño3.4 kèm độ trễ công bố) |
| **B5** Bối cảnh vùng | past: như A5 |

### 6.2. Ma trận thí nghiệm [ĐỀ XUẤT]

- **Sản phẩm A:** S0 = A0; S1 = +A1; S2 = +A2; S3 = +A3; S4 = +A4; S5 = +A5. Thêm **LOGO** (bỏ từng nhóm khỏi cấu hình tốt nhất) và Oracle.
- **Sản phẩm B:** L0 … L5 tương ứng B0 … B5, cùng LOGO.
- **Quy tắc:** cố định kiến trúc và siêu tham số (chỉnh một lần trên cấu hình đầy đủ dựa vào validation); 3 seed (5 seed cho 3 cấu hình cuối); chọn cấu hình chỉ dựa trên validation.
- **Pilot trước khi chạy đầy đủ:** S0, S1, S4 trên khoảng 30 ô, 2 seed. Nếu hiệu số theo cặp có khoảng tin cậy không chứa 0 thì chạy ma trận đầy đủ.

### 6.3. Thí nghiệm độ trễ quan trắc [ĐỀ XUẤT, đóng góp chính của sản phẩm A]

- Thay L ∈ {0,5; 2; 4; 8; 14 giờ; ∞} cho cấu hình tốt nhất, rồi vẽ kỹ năng theo (hạn dự báo × độ trễ), **tách theo mùa**.
- Kết quả trả lời trực tiếp câu hỏi: dùng GSMaP NRT (khoảng 4 giờ), GSMaP_NOW (khoảng 0,5 giờ), hay không có quan trắc thì được bao nhiêu. Thí nghiệm cũng cho luôn mô hình dự phòng (L = ∞).
- **Giả thuyết:** quan trắc giúp nhiều ở +1…+3 giờ rồi giảm nhanh; mùa đông gần như không giúp; từ khoảng +4…+6 giờ, dự báo số chiếm ưu thế (gọi là "điểm giao").

### 6.4. Chia dữ liệu [ĐỀ XUẤT] [ĐÃ LÀM trong `DEFAULT_SPLIT`]

| Phần | Năm | Dùng để |
| --- | --- | --- |
| Train | 2015–2021 | Huấn luyện |
| Validation | 2022–2023 | Chọn epoch, siêu tham số, cấu hình |
| Val-ops | 2024 | Chọn biến thể triển khai theo đầu vào dự báo thật |
| Test | 2025 (gồm đợt mưa kỷ lục cuối 10/2025) | Báo cáo cuối, **chỉ mở một lần** |
| Live | Từ khi app chạy | Kiểm định trên tương lai thật |

- Chia theo năm của **giờ đích đầu tiên**; đầu vào được phép nhìn lùi sang phần trước.
- Chuẩn hóa chỉ fit trên train.
- **Kiểm định chéo cuốn chiếu theo năm** (test lần lượt 2021…2025) cho baseline và 3 cấu hình cuối.
- **Số cửa sổ:** sản phẩm A đầy đủ có 13,1 triệu train / 3,7 triệu val / 1,9 triệu val-ops / 1,9 triệu test. Sản phẩm B có 2,2 / 0,6 / 0,3 / 0,3 triệu. Mỗi epoch rút mẫu con.

### 6.5. Chỉ số [CHỐT · BẰNG CHỨNG]

- **Phân loại:** POD, FAR, CSI, FBI, ETS ở ngưỡng `>=`.
  - A: tổng 3 giờ ≥1/10/25 mm, và phân vị 90/99 % của vùng.
  - B: tổng 24 giờ ≥16/50/100 mm; tổng 12 giờ ≥8/26 mm (ngưỡng phân cấp mưa Việt Nam).
- **Xác suất:** Brier score, BSS so với khí hậu, reliability, ROC-AUC.
- **Liên tục:** MAE/RMSE của tổng 3 giờ và 24 giờ, bias, tương quan. Chỉ để tham khảo.
- **Kỹ năng tương đối:** 1 − điểm(mô hình) / điểm(ECMWF thô).
- **Chỉ số chính đăng ký trước:** A dùng CSI (3 giờ ≥10 mm) và BSS (có mưa). B dùng CSI (24 giờ ≥50 mm) và BSS (≥16 mm).
- **Tách theo:** hạn, mùa, giờ trong ngày, vùng, độ cao ô.
- **Phân tích sự kiện:** 14/10/2022, 13–14/10/2023, 26–29/10/2025 (Bạch Mã 1.739,6 mm/24 giờ).
- **Thống kê:** bootstrap khối theo ngày (5 ngày), so theo cặp, khoảng tin cậy 95 %.

### 6.6. Hai chế độ đầu vào [ĐỀ XUẤT]

- **T-ERA5:** đầu vào ERA5, là giới hạn trên của perfect prog.
- **T-OPS:** đầu vào là dự báo thật đã lưu trữ (Single Runs ECMWF từ 03/2024; Historical Forecast cho 0–6 giờ).
- Báo khoảng cách giữa hai chế độ theo từng hạn. Nếu kém hơn quá khoảng 30 %, fine-tune theo MOS trên dữ liệu 2024 rồi đánh giá lại trên 2025.

### 6.7. Thí nghiệm không gian [ĐỀ XUẤT]

1. Chung so với riêng.
2. Bỏ ô: giữ 20 % ô Đà Nẵng không cho vào huấn luyện.
3. Bỏ một vùng (leave-one-region-out).
4. So kỹ năng giữa ô ven biển, trung du và núi.

---

## 7. Mức sàn cần vượt [CHỐT · BẰNG CHỨNG] [ĐÃ LÀM]

Đo tại 10 trạm, 02/2024–08/2025: 5.313 trạm-ngày, 130 ngày ≥50 mm, cùng một tập mẫu cho mọi nguồn.

| Nguồn | MAE | CC | CSI ≥16 | CSI ≥50 | FBI ≥50 | BSS ≥16 | BSS ≥50 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Khí hậu | 7,16 | 0,26 | 0,10 | 0,00 | 0,00 | −0,55 | −0,06 |
| Persistence | 7,54 | 0,34 | 0,17 | 0,11 | 1,02 | −0,72 | −0,72 |
| ERA5 | 6,06 | 0,57 | 0,25 | 0,17 | 0,48 | −0,46 | −0,11 |
| **ECMWF trước 1 ngày** | 6,48 | 0,52 | 0,25 | **0,16** | **0,47** | −0,53 | −0,12 |
| ECMWF trước 3 ngày | 6,75 | 0,45 | 0,25 | 0,12 | 0,46 | −0,53 | −0,23 |
| ECMWF trước 5 ngày | 7,14 | 0,34 | 0,20 | 0,09 | 0,46 | −0,66 | −0,29 |
| GFS trước 1 ngày | 6,04 | 0,57 | 0,22 | 0,16 | 0,48 | −0,42 | −0,15 |

**Kết luận:**
- ECMWF trước 1 ngày ngang ERA5: hiệu số CSI ≥50 mm là −0,01, khoảng tin cậy [−0,04; 0,03].
- Mọi nguồn lưới chỉ báo được khoảng một nửa số ngày mưa to (FBI khoảng 0,47).
- **Mọi dự báo tất định đều có BSS < 0**, nên mô hình phải xuất xác suất đã hiệu chỉnh; chỉ cần đạt BSS > 0 là đã hơn mọi nguồn hiện có trên chỉ số này.
- GFS trước 5 ngày bị loại do lỗi dữ liệu nguồn.

---

## 8. Triển khai app [ĐỀ XUẤT]

- **Luồng xử lý:** quan trắc GSMaP NRT/IMERG Early (30 phút) và dự báo ECMWF qua Open-Meteo (mỗi giờ; lượt chạy mới mỗi 6 giờ) → module đặc trưng **dùng chung với lúc huấn luyện** → Bi-LSTM (mỗi giờ) và TFT (sau mỗi lượt chạy ECMWF) → kho dự báo (`issued_at`, phiên bản mô hình, hash đầu vào) → API → web.
- **Giao diện:** bản đồ ô theo 34 tỉnh, thẻ tóm tắt cấp tỉnh, chi tiết điểm/xã, so AI với ECMWF thô, bảng kiểm chứng live.
- **Chống lệch giữa huấn luyện và chạy thật:** test parity (đơn vị, mốc giờ) và bảng ánh xạ đơn vị.
- **Dự phòng:** API lỗi thì dùng snapshot gần nhất; quan trắc lỗi thì dùng mô hình L = ∞.
- **Giới hạn Open-Meteo bản miễn phí:** chỉ phi thương mại; 10.000 lượt/ngày, 5.000/giờ, 600/phút; phải ghi nguồn CC BY 4.0. Khi lên toàn quốc, chuyển sang ECMWF Open Data (GRIB).
- **Việc gấp:** bật **ghi log live** ngay trên một máy luôn bật, vì mùa mưa 10–12 đang diễn ra.
- App không phát cảnh báo thiên tai; chỉ dẫn link bản tin chính thức NCHMF (QĐ 18/2021/QĐ-TTg).

---

## 9. Những gì đã triển khai [ĐÃ LÀM]

**Code (pipeline v2):**

| File | Vai trò |
| --- | --- |
| `src/verification.py` | Chỉ số dùng chung (ngưỡng `>=`), BSS, reliability, bootstrap khối theo cặp, fold cuốn chiếu |
| `src/baselines.py` | Khí hậu theo ngày trong năm, persistence |
| `src/station_registry.py`, `src/admin_regions.py` | 12 trạm synop; ánh xạ 63 tỉnh cũ (GAUL) sang 34 tỉnh mới |
| `src/dataset_v2.py` | Nội suy ERA5 về ô, mã hóa CIN, thống kê lân cận, đặc trưng thời gian |
| `src/dataloader_v2.py` | `WindowConfig`, `product_a/b`, `FEATURE_GROUPS`, `sample_index`, `Normalizer`, `WindowSampler`, `epoch_subset`, `torch_dataset` |
| `scripts/fetch_gsod_stations.py`, `fetch_openmeteo_baselines.py`, `station_daily_benchmark.py` | Dữ liệu trạm, bảng baseline, Thí nghiệm 0 |
| `scripts/extract_gee_precip.py`, `extract_gee_era5.py`, `extract_gee_static.py` | Tải từ Google Earth Engine (cần `--project`) |
| `scripts/build_dataset_v2.py`, `inspect_dataloader_v2.py` | Dựng dataset; kiểm tra dataloader (0/50 mẫu lệch; batch 256 đọc trong 0,03–0,14 s; đỉnh RAM 1,7 GB) |
| `scripts/package_data.py`, `download_progress.py` | Đóng gói/kiểm tra dữ liệu bằng checksum; theo dõi tiến độ tải |
| `scripts/make_evidence_figures.py` | 5 hình minh chứng, nằm ở `reports/evidence/` (**chưa commit**) |

**Kiểm thử:** 34 unit test cho phần mới, tất cả đều đạt.

**Báo cáo:**
- `reports/station_benchmark/` (bảng baseline và Thí nghiệm 0).
- `reports/dataloader_v2/summary.json`.
- `reports/evidence/`.

**Tài liệu:** `project_plan_v2.md`, `KE_HOACH_DU_AN.md`, `CLAUDE.md`, `AGENTS.md`, README.

**Bàn giao:**
- Gói dữ liệu 2,9 GB kèm manifest, tải lên Google Drive.
- Bộ slide 14 trang về dữ liệu và mô hình, trên claude.ai, ở chế độ riêng tư.

**Chưa làm:** huấn luyện bất kỳ mô hình nào trên dữ liệu mới; baseline trên lưới; T-OPS; ghi log live; app mới.

---

## 10. Lộ trình [ĐỀ XUẤT] (giả định nộp cuối 12/2026)

| Tuần | Thời gian | Việc | Cổng kiểm soát |
| --- | --- | --- | --- |
| 1–2 | 12–25/10 | ✅ Dữ liệu, bộ đánh giá, dataloader. Còn: baseline trên lưới, pilot Bi-LSTM, ghi log live, tải dự báo ECMWF lưu trữ | Bảng mức sàn trên lưới; pilot phân biệt được các cấu hình |
| 3–4 | 26/10–08/11 | Bi-LSTM: ablation A0–A5 (3 seed), thí nghiệm độ trễ, đánh giá tách mùa | Bi-LSTM có vượt ECMWF thô và persistence không? |
| 5–6 | 09–22/11 | TFT: cài đặt, ablation B0–B5; DLinear; Informer một cấu hình; bảng 2×2 | TFT có vượt ECMWF và ECMWF + QM không? |
| 7 | 23–29/11 | T-OPS; chọn cấu hình cho app; mở test 2025 | Đóng băng kết quả chính |
| 8 | 30/11–06/12 | 2 vùng kiểm tra; bỏ ô, bỏ vùng | Kết quả tổng quát hóa |
| 9–10 | 07–20/12 | App: bản đồ tỉnh, chi tiết điểm, kiểm chứng live | Demo chạy liên tục |
| 11 | 21–27/12 | Báo cáo, slide, phân tích sự kiện | Nộp bài |

**Phạm vi tối thiểu (MVP):**
- Chỉ Đà Nẵng.
- Bi-LSTM: A0/A1/A2/A4, 3 mức trễ.
- TFT: B0/B1/B3.
- Baseline: khí hậu, persistence, ECMWF thô, LightGBM, DLinear.
- T-OPS trên năm 2025.
- App một tỉnh, có ghi log live.

**Bỏ trước nếu phải cắt:** A5/B5, đa vùng, hạn 7 ngày, fine-tune MOS.

**Thời gian GPU ước tính:** A khoảng 15 giờ, B khoảng 15–20 giờ, tức khoảng 4–5 đêm trên RTX 4060.

---

## 11. Rủi ro

| Rủi ro | Phương án |
| --- | --- |
| AI không thắng ECMWF ở 1–3 ngày | Đây là kết quả bình thường. Tiêu chí thay thế: giảm bias, BSS > 0, reliability tốt, CSI cao hơn ở ít nhất một ngưỡng |
| T-OPS lệch lớn so với T-ERA5 | Fine-tune theo MOS trên dữ liệu 2024; dùng biến thể ít đặc trưng hơn |
| Nhãn vệ tinh vẫn sai ở vùng núi và mùa đông | Ghi vào phần Hạn chế; đánh giá theo mùa; kiểm tra lại với nhãn IMERG |
| Thiếu GPU hoặc thời gian | Pilot trước; giảm số ô và tăng bước trượt; dùng 2 seed ở giai đoạn sàng lọc; giữ đúng phạm vi MVP |
| Kiểm chứng độc lập hạn chế | Chỉ 10 trạm, chỉ mưa ngày, chỉ đến 08/2025; mùa mưa cuối 2025 và giai đoạn live chỉ so được với vệ tinh |

---

## 12. Câu hỏi còn mở

1. Vùng kiểm tra phía nam: **TP.HCM** hay **Đắk Lắk**? (Phía bắc: Hà Nội.)
2. Hạn nộp chính xác và phân vai: dữ liệu và đánh giá / Bi-LSTM / TFT / app.
3. Máy nào chạy ghi log live liên tục?
4. Có mở rộng dữ liệu về 2001–2014 cho TFT không? Cùng script, đổi `--start`.

---

## 13. Gợi ý khi gộp với phương án khác

**Nên giữ, vì có bằng chứng đo trên dữ liệu thật:**
- D1, D2: nhãn.
- D9, D10: chỉ số và quy tắc theo mùa.
- D14: ràng buộc dữ liệu kiểm chứng.
- D15: thuật ngữ.
- Các quy ước kỹ thuật ở mục 3.3 và 3.4.

Nếu phương án kia đề xuất ngược lại, ví dụ dùng ERA5 làm nhãn, chấm bằng MAE, hay chấm theo giờ cả năm, cần yêu cầu bằng chứng đo **cùng cách** (cùng trạm, cùng giai đoạn, cùng chỉ số) trước khi đổi.

**Có thể thay nếu phương án kia hợp lý hơn:**
- D4–D5: phạm vi và vùng.
- D11–D13: chi tiết thí nghiệm.
- Kiến trúc cụ thể của TFT; danh sách đặc trưng trong từng nhóm; lộ trình; công nghệ làm app.

**Tiêu chí để so hai phương án:**
1. Nhãn có được kiểm chứng với số đo thật không?
2. Mọi đầu vào có sẵn khi app chạy thật không, với đúng độ trễ?
3. So sánh có cùng tập test, có baseline (đặc biệt ECMWF thô), có khoảng tin cậy không?
4. Chỉ số có phù hợp với sự kiện hiếm (CSI, BSS) không?
5. Có khả thi với máy 8 GB RAM, một GPU 8 GB, và khoảng 10 tuần không?
6. Có tái sử dụng được phần đã làm ở mục 9 không?

---

## 14. Tài liệu tham khảo

**Quy định:**
- Thông tư 08/2022/TT-BTNMT (thời hạn dự báo).
- Nghị quyết 202/2025/QH15 (sắp xếp đơn vị hành chính cấp tỉnh).
- QĐ 18/2021/QĐ-TTg (dự báo, cảnh báo thiên tai).
- Phân cấp mưa: mưa vừa 16–50 mm/24 giờ, mưa to 51–100, rất to >100 (Báo Chính phủ, thuật ngữ bản tin KTTV).

**Dữ liệu:**
- GSMaP v8 (JAXA; Kubota et al., 2020).
- IMERG V07 (NASA).
- ERA5 (ECMWF).
- NOAA GSOD.
- Open-Meteo: Historical Forecast, Previous Runs, Single Runs.
- Copernicus DEM, FAO GAUL.

**Phương pháp:**
- Kratzert et al. (2019) HESS 23:5089 và WRR 55:11344.
- Montero-Manso & Hyndman (2021) IJF 37:1632.
- Rasp & Lerch (2018) MWR 146:3885.
- Zeng et al. (2023) AAAI, DLinear.
- Lim et al. (2021) IJF, Temporal Fusion Transformer.
- Koya & Roy (2023), TFT cho dự báo dòng chảy.
- Das et al. (2023) TMLR, TiDE.
- Zhou et al. (2021) AAAI, Informer.
- Vannitsem et al. (2021) BAMS, hậu xử lý thống kê.
- Hamill (1999) WAF, kiểm định giả thuyết cho dự báo mưa.
- Espeholt et al. (2022) Nature Communications, MetNet-2.
- Trần An Đức và cộng sự (2025), Tạp chí KTTV, quantile mapping ECMWF cho Trung Bộ.
